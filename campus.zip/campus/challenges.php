<?php

session_start();

 require_once 'components/database.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Campus Connect</title>

    <?php require_once 'components/links.php'; ?>
    <style>
    .navigation ul {
        list-style-type: none;
        margin: 0;
        padding: 0;

    }

    .navigation li {
        float: left;
    }

    .navigation li a {
        color: black;
        font-weight: bold;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    .navigation li a:hover {
        color: black;
        border-bottom: 1.2px solid black;
        font-weight: bold;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }





    .section-title h2 {
        text-align: center;
        font-size: 18px;
        font-weight: 600;
        text-transform: uppercase;
        padding-bottom: 6px;
        color: #000;
        letter-spacing: 0.3px;
        padding: 0;
    }

    .section-title::after {
        content: "";
        height: 3px;
        background: #fbb900;
        width: 80px;
        position: absolute;
        left: 0;
        right: 0;
        margin: auto;
    }

    #challenges-section {
        background-image: url('img/challenge-landing.jpg');
        background-position: center center;
        background-size: cover;
        min-height: 13rem;
        text-transform: uppercase;
        font-weight: 700;
        background-color: #706e94;
    }

    .challenges-type .card {
        color: #676491 !important;
        background-color: #fff !important;
        border-radius: 6px;
        padding: 20px;
        position: relative;
        margin-top: -3.8rem;
    }

    .challenges-type .card p {
        color: #676491 !important;
        font-size: 22px;
        font-weight: 600;
        padding-bottom: 0.8px;
        border-bottom: 0.2px solid #706e94;
    }

    .button-types .btn-challenge {
        text-align: center !important;
        padding: 7px 18px;
        font-size: 18px;
        font-weight: 500;

    }

    a{
        text-decoration:none !important;
        list-style-type: none !important;
    }

    .button-types .active-btn {
        background: #676491 !important;
        color: #fff !important;
    }

    .button-types a:nth-child(1) {
        border-top-left-radius: 25px;
        border-bottom-left-radius: 25px;
    }

    .button-types a:nth-child(3) {
        border-top-right-radius: 25px;
        border-bottom-right-radius: 25px;
    }

    .challenges-result .result-title {
        color: #676491 !important;
        font-size: 25px;
        font-weight: 600;

    }

    .challenges-result .result-title span {
        padding: 5px 15px;

    }

    .challenge-detail-card {
        color: #676491 !important;
        background-color: #FAFAFA !important;
        border-radius: 6px;
        padding: 10px 5px;
        position: relative;
        margin-top: -7.8rem;
    }

    .challenge-detail-card ul {
        list-style-type: none;
        padding: 0px !important;
        margin: 15px 0px !important;
    }

    .challenge-detail-card .challenge-type {
        font-size: 15px;
        font-weight: 500;
        color: #676491;
    }

    .challenge-detail-card .challenge-title {
        font-size: 18px;
        font-weight: 600;
        color: #676491;
    }

    .challenge-detail-card .challenge-start-on {
        font-size: 17px;
        font-weight: 600;
        color: #85839e;
    }

    .challenge-detail-card .challenge-start-time {
        font-size: 17px;
        font-weight: 600;
        color: #57557a;
    }

    .challenge-detail-card .challenge-register-btn {
        padding: 8px 30px;
        border: 1.5px solid #676491;
        color: #676491;
        background: #fff;
        font-weight: bold;
        text-transform: uppercase;
        border-radius: 3px;
        margin-top: 2px !important;

    }

    .challenge-detail-card .challenge-register-btn:hover {
        padding: 8px 30px;
        border: 1.5px solid #fff;
        color: #fff;
        background: #676491;
        font-weight: bold;
        text-transform: uppercase;

    }
    </style>
</head>

<body>


    <?php require_once 'components/navbar.php'; ?>



    <section id="challenges-section">
        <div class="container-fluid py-5 mt-5">

        </div>
    </section>

    <section class="challenges-type">
        <div class="container">
            <div class="card shadow text-center shadow-lg p-3 mb-5 bg-white rounded">
                <p class="text-center">Events</p>
                <div class="button-types" id="button-types">
                    <a href="<?php echo $base_url; ?>/challenges?type=live" class="btn-challenge">Live</a>
                    <a href="<?php echo $base_url; ?>/challenges?type=upcoming" class="btn-challenge">Upcoming</a>
                    <a href="<?php echo $base_url; ?>/challenges?type=past" class="btn-challenge">Past</a>
                </div>
            </div>
        </div>
    </section>

    <section class="challenges-result" id="challenges-fetch">


    </section>



    <?php require_once 'components/footer.php'; ?>
    <!-------- Mobile nav-------->

    <?php require_once 'components/mobile-nav.php'; ?>


</body>

</html>

<script>
const currentLocation = location.href;
const menuItem = document.querySelectorAll('#button-types a');
for (let i = 0; i < menuItem.length; i++) {
    if (menuItem[i].href === currentLocation) {
        menuItem[i].classList.add("active-btn");
    }
}
</script>
<script>
setInterval(get_fb, 1000);


function get_fb() {


    var feedback = $.ajax({
        //data :{action: "showroom"},
        url: "load.php", //php page URL where we post this data to view from database
        method: 'POST',
        dataType: 'text',
        success: function(data) {

        }
    }).responseText;


}
</script>

<script language="javascript" type="text/javascript">
setInterval(reloadChallenges, 1000);



function reloadChallenges() {
    $('#challenges-fetch').load('fetch-challenges.php?status=<?php echo $_GET['type'] ?>', function() {});
}
</script>


<script>
$('.carousel').carousel({
    interval: 4000
})
</script>


<!-- Slider JS Link -->
<script src="assets/js/lightslider.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.15/jquery.bxslider.min.js"
    integrity="sha512-p55Bpm5gf7tvTsmkwyszUe4oVMwxJMoff7Jq3J/oHaBk+tNQvDKNz9/gLxn9vyCjgd6SAoqLnL13fnuZzCYAUA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
$('.carousel-client').bxSlider({
    auto: true,
    slideWidth: 234,
    minSlides: 2,
    maxSlides: 5,
    controls: false
});
</script>
<!-- External JS Link -->
<script src="assets/js/main.js"></script>
<script>
$(document).ready(function() {
    $('#autoWidth,#autoWidth2').lightSlider({
        autoWidth: true,
        loop: true,
        onSliderLoad: function() {
            $('#autoWidth,#autoWidth2').removeClass('cS-hidden');
        }
    });
});
</script>