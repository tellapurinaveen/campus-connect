<?php

include 'components/database.php';

?>



<div class="container" style="display:none;">
    <div class="card-body">
        <div class="table-responsive ">
            <table class="table table-hover table-bordered" width="100%" cellspacing="0">
                <thead style="background-color:#8aabdb !important;">
                    <tr>
                        <th style="display:none;">ID</th>
                        <th>START</th>
                        <th>END</th>
                        <th>Duration</th>
                    </tr>
                </thead>
                <tbody>

                    <?php


                            $query = "SELECT * FROM events";
                            $query_run = mysqli_query($connection,$query);
              
                               if(mysqli_num_rows($query_run) > 0){
                                   while($row = mysqli_fetch_assoc($query_run)){
                                ?>
                    <tr>
                        <td><?php echo $row['challenge_id'] ?></td>

                        <td><?php echo $row['event_start'] ?></td>
                        <td><?php echo $row['event_end'] ?></td>

                        <td><?php 
                                    $start_time = $row['event_start']; 
                                    $start = strtotime($start_time);
                                     echo date('d-M (  h:i', $start) 
                                    ?> - <?php 
                                    $end_time = $row['event_end'];
                                    $end = strtotime($end_time);
                                    echo date('h:i )', $end); 

                                    $diff = $end - $start;
                                    ?>
                        </td>

                        <td><?php echo round(date($diff/3600), 2); ?> hrs</td>

                        <td>
                            <?php

                                date_default_timezone_set('Asia/Kolkata');
                                $date = date('Y-m-d H:i', time());

                                $start_time = $row['event_start']; 
                                    $start = strtotime($start_time);
                                     $starting =  date('Y-m-d H:i', $start);

                                $end_time = $row['event_end'];
                                    $end = strtotime($end_time);
                                    $ending =  date('Y-m-d H:i', $end);
                                    
                                    
                                    if($date < $starting)
                                    {
                                        $id = $row['challenge_id'];
                                       
                                        $query1 = "UPDATE events SET  status ='upcoming' WHERE challenge_id='$id' ";
                                        $query_run1 = mysqli_query($connection,$query1);
    
                                       
                                    }
                                    else if($date >=  $starting && $date <= $ending){
                                        $id = $row['challenge_id'];
    
                                        $query2 = "UPDATE events SET  status ='live' WHERE challenge_id='$id' ";
                                        $query_run2 = mysqli_query($connection,$query2);
                                       
                                    }
                                    else if($date > $ending){
                                        $id = $row['challenge_id'];
    
                                        $query3 = "UPDATE events SET  status ='past' WHERE challenge_id='$id' ";
                                        $query_run3 = mysqli_query($connection,$query3);

                                    }
    



                                    ?>
                        </td>

                    </tr>

                    <?php
                                   }
                               }
                               else{
                                   ?>
                    <div class="alert alert-danger text-center font-weight-bold" role="alert">NO CLASSES FOUND</div>
                    <?php
                               }
                               ?>


                </tbody>
            </table>
        </div>

    </div>

</div>