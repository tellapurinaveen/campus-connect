<?php 

	$connection = mysqli_connect("localhost","root","","campus_connect") or die('Could not connect: ' . mysql_error());
  
 ?>