<!-- Meta Tags -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Intern Call">
<meta name="keywords"
    content="Free internships, interncall, workshops for students , hackthons for students, student workshops">
<meta name="author" content="Kishore , Narendra">
<meta name="theme-color" content="#676491">
<link rel="shortcut icon" href="assets/images/logo.png" sizes="16x16" />
<!-- Bootstrap 4 cdn links -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!-- Custom Css link -->
<link rel="stylesheet" href="assets/css/style.css">
<!-- Ajax Cdn  link -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Font Awesome cdn  link -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">