<?php

include 'security.php';




    /* Admin Login */

    if(isset($_POST['login']))
    {

        $name = mysqli_real_escape_string($connection,htmlspecialchars(stripslashes(trim($_POST['name']))));
        $pass = mysqli_real_escape_string($connection,htmlspecialchars(stripslashes(trim($_POST['pass']))));
        $query = "SELECT * FROM admin WHERE email = '$name' OR name = '$name'";
        $query_run = mysqli_query($connection,$query);
        $count = mysqli_num_rows($query_run);
    

        if($count > 0)
        { 
            $row = mysqli_fetch_assoc($query_run);
            if(password_verify($pass,$row['password']))
            {

                    $_SESSION['admin_id'] = $row['id'];
                    $_SESSION['admin_name'] = $row['name'];
                    header('Location: index.php');

            }
            else{

                $_SESSION['status'] = "Incorrect Credentials Please Check Once Again";
                header('Location: login.php');
            }
        }
        else{
            $_SESSION['status'] = "Admin Account Doesn't Exists";
            header('Location: login.php');
        }

    }



    /*Admin Logout */

    if(isset($_POST['logout']))
    {

        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        header('Location: login.php');
    }





 
    /*Add College*/

    if(isset($_POST['add_college']))
    {
    


            $college_name = $_POST['college_name'];
            $principal_name = $_POST['principal_name'];
            $email = $_POST['email'];
            $logo = $_POST['college_logo'];
            $mobile = $_POST['mobile'];
            $password = password_hash($mobile, PASSWORD_BCRYPT);
         
            date_default_timezone_set('Asia/Kolkata');
            $created_at = date('d-m-Y');

            $query = "INSERT INTO colleges (college_name,logo,principal_name,email,mobile,password,created_at) VALUES ('$college_name','$logo','$principal_name','$email','$mobile','$password','$created_at')";
            $query_run = mysqli_query($connection,$query);

        

            if($query_run)
            {
                $_SESSION['success'] = "New college Added Successfully";
                header('Location: colleges.php');
            }
            else
            {
                $_SESSION['status'] = "Failed To Add New college";
                header('Location: colleges.php');
            }




    }








  /*Update College */

  if(isset($_POST['update_college']))
  {
  
            $id = $_POST['update_collegeid'];     
            $college_name = $_POST['college_name'];
            $logo = $_POST['college_logo'];
            $principal_name = $_POST['principal_name'];
            $email = $_POST['email'];
            $mobile = $_POST['mobile'];
            $password = password_hash($mobile, PASSWORD_BCRYPT);
         
      $query = "UPDATE colleges SET college_name = '$college_name',principal_name='$principal_name',logo = '$logo',email ='$email',mobile ='$mobile',password='$password' WHERE id = '$id'";
      $query_run = mysqli_query($connection,$query);
                                                              
      if($query_run)
      {
              $_SESSION['success'] = "College Updated Successfully";
              header('Location:colleges.php');
      }
      else
      {
          $_SESSION['status'] = "Failed To Update College";
          header('Location:colleges.php');
      }


  }


  /* Delete  College */

  if(isset($_POST['delete_college']))
  {
                                                                                   
          $id = $_POST['delete_collegeid'];                                                                       
          $query = "DELETE FROM colleges WHERE id='$id' ";
          $query_run = mysqli_query($connection,$query);
                                                           
          if($query_run)
          {
                  $_SESSION['success'] = "College Deleted Successfully... :)";
                  header('Location:  colleges.php');
          }
          else
          {
                  $_SESSION['status'] = "College Not Deleted ? Try Again....";
                  header('Location:   colleges.php');
          }
                                                                                              
  }  















 
    /*Add Event*/

    if(isset($_POST['add_event']))
    {
    
        $token = '123412321321412320970033241232412321421232121241201089723223232123208078011324';
        $token = str_shuffle($token);
        $challenge_id = substr($token, 0, 10);

        

            $event_name = $_POST['event_name'];
            $college_id = $_POST['college_id'];
            $registration_start = $_POST['r-starts'];
            $registration_close = $_POST['r-closes'];
            $event_start = $_POST['e-starts'];
            $event_end = $_POST['e-ends'];
            $winners = $_POST['winners'];
            $gallery = $_POST['gallery'];
            $place = $_POST['place'];
            $details = $_POST['details'];
            $image = $_POST['image'];
            $link = $_POST['link'];
            $status = 'upcoming';
         
            date_default_timezone_set('Asia/Kolkata');
            $created_at = date('d-m-Y');

            $query = "INSERT INTO events (challenge_id,title,college_name,registration_start,registration_close,event_start,event_end,place,details,image,link,winners,gallery,status,created_at) VALUES ('$challenge_id','$event_name','$college_id','$registration_start','$registration_close','$event_start','$event_end','$place','$details','$image','$link','$winners','$gallery','$status','$created_at')";
            $query_run = mysqli_query($connection,$query);

        

            if($query_run)
            {
                $_SESSION['success'] = "New Event Added Successfully";
                header('Location: events.php');
            }
            else
            {
                $_SESSION['status'] = "Failed To Add New Event";
                header('Location: events.php');
            }




    }








  /*Update Event */

  if(isset($_POST['update_event']))
  {
  
    $challenge_id = $_POST['update_eventid'];   

    $event_name = $_POST['event_name'];
    $college_id = $_POST['college_id'];
    $registration_start = $_POST['r-starts'];
    $registration_close = $_POST['r-closes'];
    $event_start = $_POST['e-starts'];
    $event_end = $_POST['e-ends'];
    $winners = $_POST['winners'];
    $gallery = $_POST['gallery'];
    $place = $_POST['place'];
    $details = $_POST['details'];
    $image = $_POST['image'];
    $link = $_POST['link'];

 
    $query = "UPDATE events SET title = '$event_name',gallery='$gallery',college_name ='$college_id',registration_start = '$registration_start' , registration_close = '$registration_close' ,winners = '$winners', event_start = '$event_start' , event_end = '$event_end' , place = '$place' , details = '$details', image = '$image', link = '$link' WHERE challenge_id = '$challenge_id'";
    $query_run = mysqli_query($connection,$query);
                                                              
      if($query_run)
      {
              $_SESSION['success'] = "Event Updated Successfully";
              header('Location:events.php');
      }
      else
      {
          $_SESSION['status'] = "Failed To Update Event";
          header('Location:events.php');
      }


  }


  /* Delete  Event */

  if(isset($_POST['delete_event']))
  {
                                                                                   
          $id = $_POST['delete_eventid'];                                                                       
          $query = "DELETE FROM events WHERE challenge_id='$id' ";
          $query_run = mysqli_query($connection,$query);
                                                           
          if($query_run)
          {
                  $_SESSION['success'] = "Event Deleted Successfully... :)";
                  header('Location:  events.php');
          }
          else
          {
                  $_SESSION['status'] = "Event Not Deleted ? Try Again....";
                  header('Location:   events.php');
          }
                                                                                              
  }  














 
    /*Add Hackthon*/

    if(isset($_POST['add_hackthon']))
    {
    


            $title = $_POST['title'];
            $description = $_POST['description'];
            $image = $_POST['image'];
            $duration = $_POST['duration'];
            $location = $_POST['location'];
         
            date_default_timezone_set('Asia/Kolkata');
            $created_at = date('d-m-Y');

            $query = "INSERT INTO hackthons (name,image,basic_requirement,duration,location,created_at) VALUES ('$title','$image','$description','$duration','$location','$created_at')";
            $query_run = mysqli_query($connection,$query);

        

            if($query_run)
            {
                $_SESSION['success'] = "New hackthon Added Successfully";
                header('Location: hackthons.php');
            }
            else
            {
                $_SESSION['status'] = "Failed To Add New hackthon";
                header('Location: hackthons.php');
            }




    }








  /*Update Hackthons */

  if(isset($_POST['update_hackthon']))
  {
  

      $id = $_POST['update_hackthonid'];
      $title = $_POST['title'];
      $image = $_POST['image'];
      $description = $_POST['description'];
      $duration = $_POST['duration'];
      $location = $_POST['location'];


      $query = "UPDATE challenges SET title = '$title',team_size ='$team_size',registration_start = '$registration_start' , registration_close = '$registration_close' , battleground_start = '$battleground_start' , battleground_ends = '$battleground_ends' , prize = '$prize' , entry_amount = '$entry_amount' WHERE challenge_id = '$challenge_id'";
      $query_run = mysqli_query($connection,$query);
                                                          
      
                                                              
      if($query_run)
      {
              $_SESSION['success'] = "hackthon Updated Successfully";
              header('Location:hackthons.php');
      }
      else
      {
          $_SESSION['status'] = "Failed To Update hackthon";
          header('Location:hackthons.php');
      }


  }


  /* Delete  Hackthons */

  if(isset($_POST['delete_hackthon']))
  {
                                                                                   
          $id = $_POST['delete_hackthonid'];                                                                       
          $query = "DELETE FROM hackthons WHERE id='$id' ";
          $query_run = mysqli_query($connection,$query);
                                                           
          if($query_run)
          {
                  $_SESSION['success'] = "hackthon Deleted Successfully... :)";
                  header('Location:  hackthons.php');
          }
          else
          {
                  $_SESSION['status'] = "hackthon Not Deleted ? Try Again....";
                  header('Location:   hackthons.php');
          }
                                                                                              
  }  





























































  

 
    /*Add Modal Paper*/

    if(isset($_POST['add_paper']))
    {
    


            $title = $_POST['title'];
            $description = $_POST['description'];
            $year_sem = $_POST['year_sem'];
            $paper_type = $_POST['paper_type'];
            $year = $_POST['year'];
            $link = $_POST['link'];
            $uploaded_by =  'Admin';
            date_default_timezone_set('Asia/Kolkata');
            $uploaded_at = date('d-m-Y');

            $query = "INSERT INTO modal_papers (title,description,year_sem,paper_type,year,link,uploaded_by,uploaded_at) VALUES ('$title','$description','$year_sem','$paper_type','$year','$link','$uploaded_by','$uploaded_at')";
            $query_run = mysqli_query($connection,$query);

        

            if($query_run)
            {
                $_SESSION['success'] = "New Modal Paper Added Successfully";
                header('Location: modal_papers.php');
            }
            else
            {
                $_SESSION['status'] = "Failed To Add New Modal Paper";
                header('Location: modal_papers.php');
            }




    }








  /*Update Modal Paper */

  if(isset($_POST['update_paper']))
  {
  

      $id = $_POST['update_paperid'];
      $title = $_POST['title'];
      $description = $_POST['description'];
      $year_sem = $_POST['year_sem'];
      $paper_type = $_POST['paper_type'];
      $year = $_POST['year'];
      $link = $_POST['link'];
  
      $query = "UPDATE modal_papers SET title = '$title',description ='$description',year_sem ='$year_sem',paper_type ='$paper_type',year ='$year',link ='$link' WHERE paper_id = '$id'";
      $query_run = mysqli_query($connection,$query);
                                                              
      if($query_run)
      {
              $_SESSION['success'] = "Modal Paper Updated Successfully";
              header('Location:modal_papers.php');
      }
      else
      {
          $_SESSION['status'] = "Failed To Update Modal Paper";
          header('Location:modal_papers.php');
      }


  }


  /* Delete  Modal Paper */

  if(isset($_POST['delete_paper']))
  {
                                                                                   
          $id = $_POST['delete_paperid'];                                                                       
          $query = "DELETE FROM modal_papers WHERE paper_id='$id' ";
          $query_run = mysqli_query($connection,$query);
                                                           
          if($query_run)
          {
                  $_SESSION['success'] = "Modal Paper Deleted Successfully... :)";
                  header('Location:  modal_papers.php');
          }
          else
          {
                  $_SESSION['status'] = "Modal Paper Not Deleted ? Try Again....";
                  header('Location:   modal_papers.php');
          }
                                                                                              
  }  




  
    
?>