<?php

include 'security.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus connect - Events</title>
    <?php include 'includes/links.php'; ?>
    <script src="table2excel.js"></script>
</head>

<body>
    <?php include 'includes/navbar.php'; ?>


    <div class="container-fluid mt-4">

        <div class="d-flex justify-content-between">
            <h3><i class="fa fa-list-alt" aria-hidden="true"></i>&nbsp; Events </h3>

            <button class="btn btn-outline-success" data-toggle="modal" data-target="#add_event">Add
                Event</button>
        </div>
        <br>
        <div class="col-md-8">

            <button id="downloadexcel" class="btn btn-secondary">Export to Excel</button>
        </div>

        <br>



        <?php

if(isset($_SESSION['success']) && $_SESSION['success']!='')
{
    echo'<div class="alert alert-primary text-center font-weight-bold" role="alert">'.$_SESSION['success'].'</div>';
    unset($_SESSION['success']);
}

if(isset($_SESSION['status']) && $_SESSION['status']!='')
{
    echo'<div class="alert alert-danger text-center font-weight-bold" role="alert">'.$_SESSION['status'].'</div>';
    unset($_SESSION['status']);
}

?>



        <!-- Add college Modal -->
        <div class="modal fade" id="add_event" tabindex="-1" role="dialog" aria-labelledby="add_eventTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="add_eventLongTitle">Add New Event</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body  text-left">


                        <form action="code.php" method="POST">

                            <div class="form-group">
                                <label class="font-weight-bold">Event Title</label>
                                <input type="text" name="event_name" class="form-control" placeholder="Enter Event Name"
                                    required>
                            </div>

                            <br>
                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">R-STARTS ON</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="r-starts">
                            </div>

                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">R-CLOSES AT</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="r-closes">
                            </div>

                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">E-STARTS AT</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="e-starts">
                            </div>

                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">E-ENDS ON</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="e-ends">
                            </div>


                            <div class="form-group">
                                <label class="font-weight-bold">Place</label>
                                <input type="text" name="place" class="form-control" placeholder="Enter Event Place"
                                    required>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Details</label>
                                <input type="text" name="details" class="form-control" placeholder="Enter event Details"
                                    required>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Image</label>
                                <input type="text" name="image" class="form-control" placeholder="Enter Image Link"
                                    required>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Link</label>
                                <input type="text" name="link" class="form-control"
                                    placeholder="Enter Registration Link" required>
                            </div>





                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="add_event" class="btn btn-primary">Add Event</button>
                    </div>

                    </form>
                </div>
            </div>
        </div>


        <!--Update College-->
        <div class="modal fade" id="update_event" tabindex="-1" role="dialog" aria-labelledby="update_eventTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="update_eventLongTitle">Update College</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body text-left">

                        <form action="code.php" method="POST">

                            <input type="hidden" name="update_eventid" id="update_eventid">


                            <div class="form-group">
                                <label class="font-weight-bold">Event Title</label>
                                <input type="text" name="event_name" id="event_name" class="form-control"
                                    placeholder="Enter Event Name" required>
                            </div>




                            <br>
                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">R-STARTS ON</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="r-starts" id="r-starts">
                            </div>

                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">R-CLOSES AT</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="r-closes" id="r-closes">
                            </div>

                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">E-STARTS AT</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="e-starts" id="e-starts">
                            </div>

                            <div class="input-group mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">E-ENDS ON</span>
                                </div>
                                <input type="datetime-local" class="form-control" name="e-ends" id="e-ends">
                            </div>


                            <div class="form-group">
                                <label class="font-weight-bold">Place</label>
                                <input type="text" name="place" id="place" class="form-control"
                                    placeholder="Enter Event Place" required>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Details</label>
                                <input type="text" name="details" id="details" class="form-control"
                                    placeholder="Enter event Details" required>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Image</label>
                                <input type="text" name="image" id="image" class="form-control"
                                    placeholder="Enter Image Link" required>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Link</label>
                                <input type="text" name="link" id="link" class="form-control"
                                    placeholder="Enter Registration Link" required>
                            </div>




                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="update_event" class=" btn btn-primary">Update
                            Event</button>
                    </div>

                    </form>
                </div>
            </div>
        </div>






        <!-- Delete Event-->
        <div class="modal fade" id="delete_event" tabindex="-1" role="dialog" aria-labelledby="delete_eventCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="delete_eventLongTitle">Delete Event</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="code.php" method="POST">

                            <input type="hidden" name="delete_eventid" id="delete_eventid">

                            <h4>Do You Want to Delete this Event </h4>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">NO</button>
                                <button type="submit" name="delete_event" class="btn btn-primary">YES</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>













        <br>
        <?php
                            date_default_timezone_set('Asia/Kolkata');
                            $date = date('d-m-Y');

                            $query = "SELECT * FROM events";
                            $query_run = mysqli_query($connection,$query);

                    ?>

        <div class="table-responsive text-nowrap">
            <table id="example_table" class="table table-bordered table-striped text-center">
                <thead style="background-color:#55198B !important;color:#fff !important;">
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>College Name</th>
                        <th>Registration Start</th>
                        <th>Registration Close</th>
                        <th>Event Start</th>
                        <th>Event End</th>
                        <th>Place</th>
                        <th>Details</th>
                        <th>Image</th>
                        <th>Link</th>
                        <th>Created At</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    if(mysqli_num_rows($query_run) > 0)
                    {
                    while($row = mysqli_fetch_assoc($query_run))
                    {

                    ?>
                    <tr>
                        <td><?php echo $row['challenge_id'];?></td>
                        <td><?php echo $row['title'];?></td>
                        <td><?php echo $row['college_name'];?></td>
                        <td><?php echo $row['registration_start'];?></td>
                        <td><?php echo $row['registration_close'];?></td>
                        <td><?php echo $row['event_start'];?></td>
                        <td><?php echo $row['event_end'];?></td>
                        <td><?php echo $row['place'];?></td>
                        <td><?php echo $row['details'];?></td>
                        <td><?php echo $row['image'];?></td>
                        <td><?php echo $row['link'];?></td>
                        <td><?php echo $row['created_at'];?></td>
                        <td><button type="button" class="btn btn-info update_event">Edit</button></td>
                        <td><button type="button" class="btn btn-danger delete_event">Delete</button></td>
                    </tr>
                    <?php
                    }
                    }
                    else
                    {
                    echo '<td class="text-center text-danger font-weight-bold" colspan="13">No Events Found</td>';
                    }

                    ?>
                </tbody>
            </table>
        </div>


    </div>



    </div>


















    <!-- update college script -->
    <script>
    $(document).ready(function() {

        $('.update_event').on('click', function() {
            $('#update_event').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#update_eventid').val(data[0]);
            $('#event_name').val(data[1]);
            $('#r-starts').val(data[3]);
            $('#r-closes').val(data[4]);
            $('#e-starts').val(data[5]);
            $('#e-ends').val(data[6]);
            $('#place').val(data[7]);
            $('#details').val(data[8]);
            $('#image').val(data[9]);
            $('#link').val(data[10]);


        });
    });
    </script>
    <!-- delete college script -->
    <script>
    $(document).ready(function() {

        $('.delete_event').on('click', function() {
            $('#delete_event').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);
            $('#delete_eventid').val(data[0]);
        });
    });
    </script>





    <?php include 'includes/footer.php'; ?>





</body>

</html>

<script>
document.getElementById('downloadexcel').addEventListener('click', function() {
    var table2excel = new Table2Excel();
    table2excel.export(document.querySelectorAll("#example_table"));
});
</script>