<?php

session_start();
$auth = (isset($_SESSION['college_id']) && isset($_SESSION['college_name']));

if(!$auth)
{
    header("Location: login.php");
}

include "database.php";


?>