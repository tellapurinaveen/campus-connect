<?php

include 'security.php';




    /* College Login */

    if(isset($_POST['login']))
    {

        $name = mysqli_real_escape_string($connection,htmlspecialchars(stripslashes(trim($_POST['name']))));
        $pass = mysqli_real_escape_string($connection,htmlspecialchars(stripslashes(trim($_POST['pass']))));
        $query = "SELECT * FROM colleges WHERE email = '$name' OR college_name = '$name'";
        $query_run = mysqli_query($connection,$query);
        $count = mysqli_num_rows($query_run);
    

        if($count > 0)
        { 
            $row = mysqli_fetch_assoc($query_run);
            if(password_verify($pass,$row['password']))
            {

                    $_SESSION['college_id'] = $row['id'];
                    $_SESSION['college_name'] = $row['college_name'];
                    header('Location: index.php');

            }
            else{

                $_SESSION['status'] = "Incorrect Credentials Please Check Once Again";
                header('Location: login.php');
            }
        }
        else{
            $_SESSION['status'] = "Admin Account Doesn't Exists";
            header('Location: login.php');
        }

    }



    /*College Logout */

    if(isset($_POST['logout']))
    {

        unset($_SESSION['college_id']);
        unset($_SESSION['college_name']);
        header('Location: login.php');
    }















 
    /*Add Event*/

    if(isset($_POST['add_event']))
    {
    
        $token = '123412321321412320970033241232412321421232121241201089723223232123208078011324';
        $token = str_shuffle($token);
        $challenge_id = substr($token, 0, 10);

        

            $event_name = $_POST['event_name'];
            $college_id =   $_SESSION['college_id'];
            $registration_start = $_POST['r-starts'];
            $registration_close = $_POST['r-closes'];
            $event_start = $_POST['e-starts'];
            $event_end = $_POST['e-ends'];
            
            $place = $_POST['place'];
            $details = $_POST['details'];
            $image = $_POST['image'];
            $link = $_POST['link'];
            $status = 'upcoming';
         
            date_default_timezone_set('Asia/Kolkata');
            $created_at = date('d-m-Y');

            $query = "INSERT INTO events (challenge_id,title,college_name,registration_start,registration_close,event_start,event_end,place,details,image,link,status,created_at) VALUES ('$challenge_id','$event_name','$college_id','$registration_start','$registration_close','$event_start','$event_end','$place','$details','$image','$link','$status','$created_at')";
            $query_run = mysqli_query($connection,$query);

        

            if($query_run)
            {
                $_SESSION['success'] = "New Event Added Successfully";
                header('Location: events.php');
            }
            else
            {
                $_SESSION['status'] = "Failed To Add New Event";
                header('Location: events.php');
            }




    }








  /*Update Event */

  if(isset($_POST['update_event']))
  {
  
    $challenge_id = $_POST['update_eventid'];   

    $event_name = $_POST['event_name'];
    $college_id = $_POST['college_id'];
    $registration_start = $_POST['r-starts'];
    $registration_close = $_POST['r-closes'];
    $event_start = $_POST['e-starts'];
    $event_end = $_POST['e-ends'];
    
    $place = $_POST['place'];
    $details = $_POST['details'];
    $image = $_POST['image'];
    $link = $_POST['link'];

 
    $query = "UPDATE events SET title = '$event_name',college_name ='$college_id',registration_start = '$registration_start' , registration_close = '$registration_close' , event_start = '$event_start' , event_end = '$event_end' , place = '$place' , details = '$details', image = '$image', link = '$link' WHERE challenge_id = '$challenge_id'";
    $query_run = mysqli_query($connection,$query);
                                                              
      if($query_run)
      {
              $_SESSION['success'] = "Event Updated Successfully";
              header('Location:events.php');
      }
      else
      {
          $_SESSION['status'] = "Failed To Update Event";
          header('Location:events.php');
      }


  }


  /* Delete  Event */

  if(isset($_POST['delete_event']))
  {
                                                                                   
          $id = $_POST['delete_eventid'];                                                                       
          $query = "DELETE FROM events WHERE challenge_id='$id' ";
          $query_run = mysqli_query($connection,$query);
                                                           
          if($query_run)
          {
                  $_SESSION['success'] = "Event Deleted Successfully... :)";
                  header('Location:  events.php');
          }
          else
          {
                  $_SESSION['status'] = "Event Not Deleted ? Try Again....";
                  header('Location:   events.php');
          }
                                                                                              
  }  





  
    
?>