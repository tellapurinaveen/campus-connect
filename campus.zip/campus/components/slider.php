<!-------- Slider-------->

<div class="container-fluid py-2">
    <!--latest-movies---------------------->
    <section id="latest">
        <br>
        <h2 class="latest-heading font-weight-bold text-center">What You Can Get From Us</h2>
        <br>
        <!--slider------------------->
        <ul id="autoWidth2" class="cs-hidden">

            <!--slide-box-2------------------>

            <?php
                    $query = "SELECT * FROM internships";
                    $query_run = mysqli_query($connection,$query);

            ?>

            <?php

if(mysqli_num_rows($query_run) > 0)
{
while($row = mysqli_fetch_assoc($query_run))
{

?>
            <li class="item-b">
                <a href="<?php echo $base_url ?>/internships.php" style="text-decoration:none;cursor:pointer;">
                    <div class="latest-box">
                        <!--img-------->
                        <div class="latest-b-img">
                            <img src="<?php echo $row['image'];?>" alt="image">
                        </div>
                        <!--text---------->
                        <div class="latest-b-text">
                            <strong><?php echo $row['name'];?></strong>
                        </div>
                    </div>
                </a>
            </li>

            <?php
                    }
                    }
                    else
                    {
                    echo '<td class="text-center text-danger font-weight-bold" colspan="13">No Internships Found</td>';
                    }

                    ?>


        </ul>
    </section>
</div>
<!-------- Slider End-------->