<?php
$base_url="http://localhost/campus";
$connection = mysqli_connect("localhost","root","","campus_connect");
?>