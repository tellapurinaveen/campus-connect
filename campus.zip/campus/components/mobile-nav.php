<?php
require_once "components/database.php";

?>
<nav class="nav-mobile">

    <a href="<?php echo $base_url; ?>/index.php"
        class="nav__link <?= (basename($_SERVER['PHP_SELF'])=="index.php")?"nav__link--active":""; ?>">
        <i class="material-icons nav__icon">school</i>
        <span class="nav__text">Home</span>
    </a>
    <a href="<?php echo $base_url; ?>/challenges?type=upcoming"
        class="nav__link <?= (basename($_SERVER['PHP_SELF'])=="challenges?type=upcoming")?"nav__link--active":""; ?>">
        <i class="material-icons nav__icon">work</i>
        <span class="nav__text">Events</span>
    </a>
    <a href="<?php echo $base_url; ?>/contactus.php"
        class="nav__link <?= (basename($_SERVER['PHP_SELF'])=="contactus.php")?"nav__link--active":""; ?> ">
        <i class="material-icons nav__icon">phone</i>
        <span class="nav__text">Contact</span>
    </a>
</nav>