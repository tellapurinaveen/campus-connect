<nav class="navbar navbar-toggleable-sm bg-inverse navbar-inverse fixed-top">
    <div class="p-2 bd-highlight"><a href="<?php echo $base_url; ?>/index.php" style="text-decoration:none;"><img
                src="assets/images/logo1.jpg" width="" height="50" alt="logo"> <a class="navbar-brand font-weight-bold"
                href="index.php">Campus Connect</a></div>

    <div class="navigation login-btn bd-highlight">
        <ul>
            <li class="link_normal <?= (basename($_SERVER['PHP_SELF'])=="index.php")?"link--active":""; ?>">
                <a href="<?php echo $base_url; ?>/index.php">Home</a>
            </li>
            <li
                class="link_normal <?= (basename($_SERVER['PHP_SELF'])=="challenges?type=upcoming")?"link--active":""; ?>">
                <a href="<?php echo $base_url; ?>/challenges?type=upcoming">Events</a>
            </li>
            <li class="link_normal <?= (basename($_SERVER['PHP_SELF'])=="contactus.php")?"link--active":""; ?>"><a
                    href="<?php echo $base_url; ?>/contactus.php">Contact
                    Us</a></li>
        </ul>
    </div>


</nav>