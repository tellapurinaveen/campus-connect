<?php

session_start();

 require_once 'components/database.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Campus Connect</title>

    <?php require_once 'components/links.php'; ?>
    <style>
    .navigation ul {
        list-style-type: none;
        margin: 0;
        padding: 0;

    }

    .navigation li {
        float: left;
    }

    .navigation li a {
        color: black;
        font-weight: bold;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    .navigation li a:hover {
        color: black;
        border-bottom: 1.2px solid black;
        font-weight: bold;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }





    .section-title h2 {
        text-align: center;
        font-size: 18px;
        font-weight: 600;
        text-transform: uppercase;
        padding-bottom: 6px;
        color: #000;
        letter-spacing: 0.3px;
        padding: 0;
    }

    .section-title::after {
        content: "";
        height: 3px;
        background: #fbb900;
        width: 80px;
        position: absolute;
        left: 0;
        right: 0;
        margin: auto;
    }
    </style>
</head>

<body>


    <?php require_once 'components/hero.php'; ?>

    <?php require_once 'components/navbar.php'; ?>



    <!-------- categories-------->

    <section class="food-items">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-10 offset-md-1 col-sm-12 justify-content-center">
                    <div class="container-fluid">
                        <h1 class="font-weight-bold restaurant-title text-center">Who We Are ?</h1>

                        <div class="row">
                            <div class="col-md-8">
                                <br>
                                <br>
                                <ul style="font-size:20px;">
                                    <li>It connects the different events of various colleges.</li>
                                    <li>You can post their events online and make the stu dents register to this events.</li>
                                    <li>We are building  communication between colleges and students.</li>
                                    <li>It has all the list of upcoming events and ongoing events such as hackathons, workshops, conferences,Symposiums and coding competitions of respective college.</li>
                                    <li>It helps you to register for events in an easy way.</li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <img src="assets/images/what.jpg" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    


                </div>
            </div>
        </div>
    </section>




    <?php require_once 'components/footer.php'; ?>
    <!-------- Mobile nav-------->

    <?php require_once 'components/mobile-nav.php'; ?>


</body>

</html>



<!-- Slider JS Link -->
<script src="assets/js/lightslider.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.15/jquery.bxslider.min.js"
    integrity="sha512-p55Bpm5gf7tvTsmkwyszUe4oVMwxJMoff7Jq3J/oHaBk+tNQvDKNz9/gLxn9vyCjgd6SAoqLnL13fnuZzCYAUA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
$('.carousel-client').bxSlider({
    auto: true,
    slideWidth: 234,
    minSlides: 2,
    maxSlides: 5,
    controls: false
});
</script>
<!-- External JS Link -->
<script src="assets/js/main.js"></script>
<script>
$(document).ready(function() {
    $('#autoWidth,#autoWidth2').lightSlider({
        autoWidth: true,
        loop: true,
        onSliderLoad: function() {
            $('#autoWidth,#autoWidth2').removeClass('cS-hidden');
        }
    });
});
</script>