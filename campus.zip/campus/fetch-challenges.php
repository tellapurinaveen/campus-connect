<?php

include 'components/database.php';
$base_url="http://localhost/campus";

$status = $_GET['status'];

$query = "SELECT * FROM events WHERE status = '$status' ORDER BY event_start ASC";
$query_run  = mysqli_query($connection,$query);
$count = mysqli_num_rows($query_run);


?>


<div class="container">

    <p class="text-left text-capitalize result-title"><?php echo $status; ?> Events &nbsp;<span
            class="badge badge-secondary"><?php echo $count; ?></span></p>
    <hr>
    <div class="row">

        <?php 




if($status == 'upcoming')
{




if($count > 0)
{
    while($row = mysqli_fetch_assoc($query_run))
    {

        $college_id = $row["college_name"];
        $query1 = "SELECT * FROM colleges WHERE id = '$college_id'";
        $query_run1  = mysqli_query($connection,$query1);
        $row1 = mysqli_fetch_assoc($query_run1);


?>

        <!-- Events Data Start -->

        <a>

            <div class="col-md-4">
                <div class="">
                    <div class="row">
                        <div class="card-body">
                            <div class="card shadow text-center bg-white rounded">
                            <img src="<?php echo $row['image'];?>" class="card-img-top" alt="..." height="200px">
                                <ul class="p-0 m-0">
                                    <li class="challenge-title text-uppercase"><b><?php echo $row['title'] ?></b></li>
                                    <hr>
                                    <div class="d-flex justify-content-around">
                                            <li class="challenge-start-on"><b>STARTS ON</b></li>
                                            <li class="challenge-start-on">-</li>
                                            <li class="challenge-start-time">
                                                <b><?php echo date('F d, h:i A', strtotime($row['event_start'])); ?></b>
                                            </li>
                                    </div>
                                    <br>
                                    <div class="d-flex justify-content-center">
                                        <li class="challenge-start-on font-weight-bold">COLLEGE -
                                        &nbsp;&nbsp;<img class='rounded' src='<?php echo $row1['logo']; ?>' width='30' height='30'> &nbsp;<?php echo $row1['college_name']; ?></li>
                                    </div>
                                    <hr>
                                    <div class="d-flex justify-content-center">
                                        <li class="challenge-start-on font-weight-bold">LOCATION
                                            &nbsp;&nbsp; - &nbsp;&nbsp; <?php echo $row['place']; ?></li>
                                    </div>
                                    <hr>

                                    <a href="<?php echo $row['link']; ?>"
                                        class="challenge-register-btn btn btn-outline-info mb-3">REGISTER</a>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </a>
        <?php
    }

?>

        <!-- Events Data End -->

    </div>
</div>
<?php
}else{
    ?>
<div class="alert container alert-danger text-center font-weight-bold" role="alert">NO UPCOMING EVENTS</div>
<?php
}

}
else if($status == 'past')
{
    


if($count > 0)
{
    while($row = mysqli_fetch_assoc($query_run))
    {


        $college_id = $row["college_name"];
        $query1 = "SELECT * FROM colleges WHERE id = '$college_id'";
        $query_run1  = mysqli_query($connection,$query1);
        $row1 = mysqli_fetch_assoc($query_run1);

?>

<!-- Events Data Start -->

<a>

    <div class="col-md-4">
        <div class="">
            <div class="row">
                <div class="card-body">
                    <div class="shadow text-center bg-white rounded p-2">   
                    <img src="<?php echo $row['image'];?>" class="card-img-top" alt="..." width="100%" height="200px">
                        <ul class="p-0 m-0">    
                            <li class="challenge-title text-uppercase"><b><?php echo $row['title'] ?></b></li>
                            <hr>
                            <div class="d-flex justify-content-around">
                                <li class="challenge-start-on text-danger"><b>EVENT OVER</b></li>
                                <li class="challenge-start-on">-</li>
                                <li class="challenge-start-time">
                                    <b><?php echo date('F d, h:i A', strtotime($row['event_end'])); ?></b></li>
                            </div>

                            <br>
                            <div class="d-flex justify-content-center">
                                <li class="challenge-start-on font-weight-bold">LOCATION &nbsp;&nbsp; -
                                &nbsp;&nbsp;<img class='rounded' src='<?php echo $row1['logo']; ?>' width='30' height='30'> &nbsp;<?php echo $row1['college_name']; ?></li>
                            </div>
                            <div class="mt-3 d-flex justify-content-center">
                                <li class="text-success challenge-start-on font-weight-bold">WINNER &nbsp;&nbsp; -
                                    <?php
                                    if($row['winners']!='')
                                    {
                                        echo $row['winners'];
                                    }
                                    else
                                    {
                                        echo 'Not Yet Updated';
                                    }
                                    ?>
                                </li>
                            </div>
                            <hr>


                            <a href="" class="btn btn-info px-3"
                                style="pointer-events:none;cursor: default;opacity: 0.6;">EVENT OVER
                            </a>
                            <?php
                                    if($row['gallery']!='')
                                    {
                                        echo '<a href="'.$row['gallery'].'" target="_blank" class="btn btn-dark px-3">EVENT GALLERY';
                                    }
                                   
                                    ?>
                            </a>


                    </div>
                </div>
            </div>


            </ul>
        </div>
    </div>


</a>
<?php
    }

?>

<!-- Events Data End -->

</div>
</div>
<?php
}else{
    ?>
<div class="alert container alert-danger text-center font-weight-bold" role="alert">NO PAST EVENTS </div>
<?php
}



}
else if($status == 'live')
{
    


if($count > 0)
{
    while($row = mysqli_fetch_assoc($query_run))
    {
    $college_id = $row["college_name"];
    $query1 = "SELECT * FROM colleges WHERE id = '$college_id'";
    $query_run1  = mysqli_query($connection,$query1);
    $row1 = mysqli_fetch_assoc($query_run1);

?>

<!-- Events Data Start -->

<a>

    <div class="col-md-4">
        <div class="">
            <div class="row">
                <div class="card-body">
                    <div class="card shadow text-center bg-white rounded">
                    <img src="<?php echo $row['image'];?>" class="card-img-top" alt="..." height="200px">
                        <ul class='p-0 m-0'>
                            <li class="challenge-title text-uppercase"><b><?php echo $row['title'] ?></b></li>
                            <hr>
                            <div class="d-flex justify-content-around">
                                <li class="challenge-start-on text-success"><b>EVENTS ENDS IN</b></li>
                                <li class="challenge-start-on">-</li>
                                <li class="challenge-start-time">
                                    <b><?php echo date('F d, h:i A', strtotime($row['event_end'])); ?></b></li>
                            </div>
                            <br>
                            <div class="d-flex justify-content-center">
                                <li class="challenge-start-on font-weight-bold text-secondary">COLLEGE &nbsp;&nbsp; -
                                    &nbsp;&nbsp;<img class='rounded' src='<?php echo $row1['logo']; ?>' width='30' height='30'> &nbsp;<?php echo $row1['college_name']; ?></li>
                            </div>
                            <hr>


                            <br>

                            <a href="" class="btn btn-info px-3 mb-3"
                                style="pointer-events:none;cursor: default;opacity: 0.6;">EVENT LIVE</a>


                    </div>
                </div>
            </div>


            </ul>
        </div>
    </div>


</a>
<?php
    }

?>

<!-- Events Data End -->

</div>
</div>
<?php
}else{
    ?>
<div class="alert container alert-danger text-center font-weight-bold" role="alert">NO LIVE EVENTS</div>
<?php
}



}


?>