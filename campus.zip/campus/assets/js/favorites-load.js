$(document).ready(function() {



    $('#dynamic_content').html(make_skeleton());

    setTimeout(function() {
        load_content();
    }, 1000);

    function make_skeleton() {
        var output = '';
        for (var count = 0; count < 8; count++) {
            output += '<div class="col-md-3 col-lg-3 mt-5">';
            output += '<div class="ph-item">';
            output += '<div class="ph-col-12">';
            output += '<div class="ph-picture"></div>';
            output += '<div class="ph-row">';
            output += '<div class="ph-col-6 big"></div>';
            output += '<div class="ph-col-6 big"></div>';
            output += '<div class="ph-col-8"></div>';
            output += '<div class="ph-col-12 big"></div>';
            output += '</div>';
            output += '</div>';
            output += '</div>';
            output += '</div>';
        }
        return output;
    }

    function load_content() {
        $.ajax({
            url: "my_favourites.php",
            method: "POST",
            success: function(data) {
                $('#dynamic_content').html(data);
            }
        })
    }
});