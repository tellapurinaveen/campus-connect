// $(function() {
//     setTimeout(function() {
//         $(".alert").hide(1)
//     }, 2000);
// });